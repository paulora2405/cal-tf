#ifndef BIG_INT_TYPE_HPP
#define BIG_INT_TYPE_HPP

#include <boost/multiprecision/cpp_int.hpp>

typedef boost::multiprecision::uint1024_t big_int;

#endif